﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyTrangTrai2
{
    class Constant
    {
        public static string NAME_GA = "Ga";
        public static string NAME_CHO = "Cho";
        public static string NAME_PIG = "Lon";

        public static string XUONG_NAME = "Xuong";
        public static double XUONG_PRICE = 10;
        public static int XUONG_LUONGTIEUTHU = 100;

        public static string CHICKEN_FOOD = "Thoc";
        public static double THOC_PRICE = 10;
        public static int THOC_LUONGTIEUTHU = 200;

        public static string PIG_FOOD = "Cam";
        public static double CAM_PRICE = 10;
        public static int CAM_LUONGTIEUTHU = 150;

    }
}
