﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyTrangTrai2
{
    class Xuong:Food
    {
        public Xuong()
        {
            Name = Constant.XUONG_NAME;
            Price = Constant.XUONG_PRICE;
        }
    }
}
