﻿namespace QuanLySinhVien_WF
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbp1 = new System.Windows.Forms.TabPage();
            this.tbp2 = new System.Windows.Forms.TabPage();
            this.grb2 = new System.Windows.Forms.GroupBox();
            this.datpDate = new System.Windows.Forms.DateTimePicker();
            this.combLop2 = new System.Windows.Forms.ComboBox();
            this.cmbKhoasv = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnXoaAnh = new System.Windows.Forms.Button();
            this.btnImport = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.txtthanhtich = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtdiemtb2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtghichu2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtsdt2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtdiachi2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtmail2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.radnu = new System.Windows.Forms.RadioButton();
            this.radnam = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txthoten2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtma2 = new System.Windows.Forms.TextBox();
            this.picb2 = new System.Windows.Forms.PictureBox();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThemMoi = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbKhoa = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.grb1 = new System.Windows.Forms.GroupBox();
            this.cmkhoa1 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.radnu1 = new System.Windows.Forms.RadioButton();
            this.radnam1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdiemtb1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comblop1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txthoten1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtma1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.picb = new System.Windows.Forms.PictureBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvLop = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvDssv = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbp3 = new System.Windows.Forms.TabPage();
            this.tbp4 = new System.Windows.Forms.TabPage();
            this.opnfd = new System.Windows.Forms.OpenFileDialog();
            this.TimerNext = new System.Windows.Forms.Timer(this.components);
            this.TimerPre = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tbp2.SuspendLayout();
            this.grb2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb2)).BeginInit();
            this.grb1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDssv)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbp1);
            this.tabControl1.Controls.Add(this.tbp2);
            this.tabControl1.Controls.Add(this.tbp3);
            this.tabControl1.Controls.Add(this.tbp4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(6, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(808, 498);
            this.tabControl1.TabIndex = 1;
            // 
            // tbp1
            // 
            this.tbp1.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.Nhung_hinh_anh_dep_ve_tinh_yeu_de_thuong_nhat_2;
            this.tbp1.Font = new System.Drawing.Font("Calibri", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbp1.Location = new System.Drawing.Point(4, 22);
            this.tbp1.Margin = new System.Windows.Forms.Padding(0);
            this.tbp1.Name = "tbp1";
            this.tbp1.Padding = new System.Windows.Forms.Padding(3);
            this.tbp1.Size = new System.Drawing.Size(800, 472);
            this.tbp1.TabIndex = 0;
            this.tbp1.Text = "Trang Chủ";
            this.tbp1.UseVisualStyleBackColor = true;
            // 
            // tbp2
            // 
            this.tbp2.BackColor = System.Drawing.SystemColors.Window;
            this.tbp2.Controls.Add(this.grb2);
            this.tbp2.Controls.Add(this.btnLuu);
            this.tbp2.Controls.Add(this.btnHuy);
            this.tbp2.Controls.Add(this.btnXoa);
            this.tbp2.Controls.Add(this.btnSua);
            this.tbp2.Controls.Add(this.btnThemMoi);
            this.tbp2.Controls.Add(this.label7);
            this.tbp2.Controls.Add(this.cmbKhoa);
            this.tbp2.Controls.Add(this.button4);
            this.tbp2.Controls.Add(this.label5);
            this.tbp2.Controls.Add(this.grb1);
            this.tbp2.Controls.Add(this.txtSearch);
            this.tbp2.Controls.Add(this.dgvLop);
            this.tbp2.Controls.Add(this.dgvDssv);
            this.tbp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tbp2.Location = new System.Drawing.Point(4, 22);
            this.tbp2.Name = "tbp2";
            this.tbp2.Padding = new System.Windows.Forms.Padding(3);
            this.tbp2.Size = new System.Drawing.Size(800, 472);
            this.tbp2.TabIndex = 1;
            this.tbp2.Text = "Sinh viên";
            // 
            // grb2
            // 
            this.grb2.Controls.Add(this.datpDate);
            this.grb2.Controls.Add(this.combLop2);
            this.grb2.Controls.Add(this.cmbKhoasv);
            this.grb2.Controls.Add(this.label19);
            this.grb2.Controls.Add(this.btnXoaAnh);
            this.grb2.Controls.Add(this.btnImport);
            this.grb2.Controls.Add(this.button10);
            this.grb2.Controls.Add(this.label18);
            this.grb2.Controls.Add(this.txtthanhtich);
            this.grb2.Controls.Add(this.label17);
            this.grb2.Controls.Add(this.txtdiemtb2);
            this.grb2.Controls.Add(this.label16);
            this.grb2.Controls.Add(this.txtghichu2);
            this.grb2.Controls.Add(this.label15);
            this.grb2.Controls.Add(this.txtsdt2);
            this.grb2.Controls.Add(this.label14);
            this.grb2.Controls.Add(this.txtdiachi2);
            this.grb2.Controls.Add(this.label13);
            this.grb2.Controls.Add(this.txtmail2);
            this.grb2.Controls.Add(this.label8);
            this.grb2.Controls.Add(this.radnu);
            this.grb2.Controls.Add(this.radnam);
            this.grb2.Controls.Add(this.label9);
            this.grb2.Controls.Add(this.label10);
            this.grb2.Controls.Add(this.label11);
            this.grb2.Controls.Add(this.txthoten2);
            this.grb2.Controls.Add(this.label12);
            this.grb2.Controls.Add(this.txtma2);
            this.grb2.Controls.Add(this.picb2);
            this.grb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.grb2.Location = new System.Drawing.Point(221, 13);
            this.grb2.Name = "grb2";
            this.grb2.Size = new System.Drawing.Size(554, 229);
            this.grb2.TabIndex = 30;
            this.grb2.TabStop = false;
            this.grb2.Text = "Thông tin sinh viên";
            this.grb2.Visible = false;
            // 
            // datpDate
            // 
            this.datpDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.datpDate.Location = new System.Drawing.Point(409, 27);
            this.datpDate.Name = "datpDate";
            this.datpDate.Size = new System.Drawing.Size(136, 20);
            this.datpDate.TabIndex = 54;
            // 
            // combLop2
            // 
            this.combLop2.FormattingEnabled = true;
            this.combLop2.Items.AddRange(new object[] {
            "TH13C",
            "Th13B",
            "TH13A"});
            this.combLop2.Location = new System.Drawing.Point(221, 122);
            this.combLop2.Name = "combLop2";
            this.combLop2.Size = new System.Drawing.Size(125, 24);
            this.combLop2.TabIndex = 53;
            // 
            // cmbKhoasv
            // 
            this.cmbKhoasv.FormattingEnabled = true;
            this.cmbKhoasv.Items.AddRange(new object[] {
            "K10",
            "K11",
            "K12",
            "K13",
            "K14"});
            this.cmbKhoasv.Location = new System.Drawing.Point(223, 87);
            this.cmbKhoasv.Name = "cmbKhoasv";
            this.cmbKhoasv.Size = new System.Drawing.Size(124, 24);
            this.cmbKhoasv.TabIndex = 52;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label19.Location = new System.Drawing.Point(150, 92);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 13);
            this.label19.TabIndex = 51;
            this.label19.Text = "Khóa";
            // 
            // btnXoaAnh
            // 
            this.btnXoaAnh.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.cancel_button;
            this.btnXoaAnh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnXoaAnh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnXoaAnh.Location = new System.Drawing.Point(96, 161);
            this.btnXoaAnh.Name = "btnXoaAnh";
            this.btnXoaAnh.Size = new System.Drawing.Size(31, 24);
            this.btnXoaAnh.TabIndex = 49;
            this.btnXoaAnh.UseVisualStyleBackColor = true;
            // 
            // btnImport
            // 
            this.btnImport.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.open_folder__2_;
            this.btnImport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnImport.Location = new System.Drawing.Point(54, 161);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(36, 24);
            this.btnImport.TabIndex = 48;
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.go_back_arrow;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.button10.Location = new System.Drawing.Point(6, 28);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(25, 30);
            this.button10.TabIndex = 47;
            this.button10.Text = "<<";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label18.Location = new System.Drawing.Point(347, 153);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 46;
            this.label18.Text = "Thành tích";
            // 
            // txtthanhtich
            // 
            this.txtthanhtich.Location = new System.Drawing.Point(409, 148);
            this.txtthanhtich.Name = "txtthanhtich";
            this.txtthanhtich.Size = new System.Drawing.Size(136, 23);
            this.txtthanhtich.TabIndex = 45;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label17.Location = new System.Drawing.Point(150, 173);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 44;
            this.label17.Text = "Điểm TB";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // txtdiemtb2
            // 
            this.txtdiemtb2.Location = new System.Drawing.Point(223, 170);
            this.txtdiemtb2.Name = "txtdiemtb2";
            this.txtdiemtb2.Size = new System.Drawing.Size(124, 23);
            this.txtdiemtb2.TabIndex = 43;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label16.Location = new System.Drawing.Point(355, 180);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 42;
            this.label16.Text = "Ghi chú";
            // 
            // txtghichu2
            // 
            this.txtghichu2.Location = new System.Drawing.Point(409, 177);
            this.txtghichu2.Name = "txtghichu2";
            this.txtghichu2.Size = new System.Drawing.Size(136, 23);
            this.txtghichu2.TabIndex = 41;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label15.Location = new System.Drawing.Point(352, 121);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "Số ĐT";
            // 
            // txtsdt2
            // 
            this.txtsdt2.Location = new System.Drawing.Point(409, 118);
            this.txtsdt2.Name = "txtsdt2";
            this.txtsdt2.Size = new System.Drawing.Size(136, 23);
            this.txtsdt2.TabIndex = 39;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label14.Location = new System.Drawing.Point(353, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 38;
            this.label14.Text = "Địa chỉ";
            // 
            // txtdiachi2
            // 
            this.txtdiachi2.Location = new System.Drawing.Point(409, 92);
            this.txtdiachi2.Name = "txtdiachi2";
            this.txtdiachi2.Size = new System.Drawing.Size(136, 23);
            this.txtdiachi2.TabIndex = 37;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label13.Location = new System.Drawing.Point(353, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "Email";
            // 
            // txtmail2
            // 
            this.txtmail2.Location = new System.Drawing.Point(409, 59);
            this.txtmail2.Name = "txtmail2";
            this.txtmail2.Size = new System.Drawing.Size(136, 23);
            this.txtmail2.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label8.Location = new System.Drawing.Point(150, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Giới tính";
            // 
            // radnu
            // 
            this.radnu.AutoSize = true;
            this.radnu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radnu.Location = new System.Drawing.Point(276, 147);
            this.radnu.Name = "radnu";
            this.radnu.Size = new System.Drawing.Size(39, 17);
            this.radnu.TabIndex = 33;
            this.radnu.Text = "Nữ";
            this.radnu.UseVisualStyleBackColor = true;
            // 
            // radnam
            // 
            this.radnam.AutoSize = true;
            this.radnam.Checked = true;
            this.radnam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radnam.Location = new System.Drawing.Point(223, 147);
            this.radnam.Name = "radnam";
            this.radnam.Size = new System.Drawing.Size(47, 17);
            this.radnam.TabIndex = 32;
            this.radnam.TabStop = true;
            this.radnam.Text = "Nam";
            this.radnam.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label9.Location = new System.Drawing.Point(353, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "Ngày sinh";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label10.Location = new System.Drawing.Point(150, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Lớp";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label11.Location = new System.Drawing.Point(150, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Họ tên";
            // 
            // txthoten2
            // 
            this.txthoten2.Location = new System.Drawing.Point(223, 57);
            this.txthoten2.Name = "txthoten2";
            this.txthoten2.Size = new System.Drawing.Size(124, 23);
            this.txthoten2.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label12.Location = new System.Drawing.Point(150, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Mã sinh viên";
            // 
            // txtma2
            // 
            this.txtma2.Location = new System.Drawing.Point(223, 28);
            this.txtma2.Name = "txtma2";
            this.txtma2.Size = new System.Drawing.Size(124, 23);
            this.txtma2.TabIndex = 24;
            // 
            // picb2
            // 
            this.picb2.BackColor = System.Drawing.Color.Gainsboro;
            this.picb2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picb2.Location = new System.Drawing.Point(40, 31);
            this.picb2.Name = "picb2";
            this.picb2.Size = new System.Drawing.Size(104, 118);
            this.picb2.TabIndex = 21;
            this.picb2.TabStop = false;
            // 
            // btnLuu
            // 
            this.btnLuu.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.save_icon;
            this.btnLuu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnLuu.Location = new System.Drawing.Point(718, 434);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(74, 32);
            this.btnLuu.TabIndex = 29;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.cancel_icon2;
            this.btnHuy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnHuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnHuy.Location = new System.Drawing.Point(638, 435);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(74, 32);
            this.btnHuy.TabIndex = 28;
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.garbage;
            this.btnXoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnXoa.Location = new System.Drawing.Point(558, 434);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(74, 32);
            this.btnXoa.TabIndex = 27;
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.couple_of_arrows_changing_places;
            this.btnSua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnSua.Location = new System.Drawing.Point(478, 435);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(74, 32);
            this.btnSua.TabIndex = 26;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThemMoi
            // 
            this.btnThemMoi.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.add_button__1_;
            this.btnThemMoi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnThemMoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnThemMoi.Location = new System.Drawing.Point(399, 435);
            this.btnThemMoi.Name = "btnThemMoi";
            this.btnThemMoi.Size = new System.Drawing.Size(73, 32);
            this.btnThemMoi.TabIndex = 25;
            this.btnThemMoi.UseVisualStyleBackColor = true;
            this.btnThemMoi.Click += new System.EventHandler(this.btnThemMoi_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.Location = new System.Drawing.Point(6, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Khóa";
            // 
            // cmbKhoa
            // 
            this.cmbKhoa.FormattingEnabled = true;
            this.cmbKhoa.Items.AddRange(new object[] {
            "K10",
            "K11",
            "K12",
            "K13",
            "K14"});
            this.cmbKhoa.Location = new System.Drawing.Point(44, 42);
            this.cmbKhoa.Name = "cmbKhoa";
            this.cmbKhoa.Size = new System.Drawing.Size(171, 21);
            this.cmbKhoa.TabIndex = 20;
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.research__3_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.button4.Location = new System.Drawing.Point(702, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 22);
            this.button4.TabIndex = 18;
            this.button4.Text = "Tìm kiếm";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label5.Location = new System.Drawing.Point(499, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Mã sinh viên";
            // 
            // grb1
            // 
            this.grb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.grb1.Controls.Add(this.cmkhoa1);
            this.grb1.Controls.Add(this.label20);
            this.grb1.Controls.Add(this.label6);
            this.grb1.Controls.Add(this.radnu1);
            this.grb1.Controls.Add(this.radnam1);
            this.grb1.Controls.Add(this.label4);
            this.grb1.Controls.Add(this.txtdiemtb1);
            this.grb1.Controls.Add(this.label3);
            this.grb1.Controls.Add(this.comblop1);
            this.grb1.Controls.Add(this.label2);
            this.grb1.Controls.Add(this.txthoten1);
            this.grb1.Controls.Add(this.label1);
            this.grb1.Controls.Add(this.txtma1);
            this.grb1.Controls.Add(this.button3);
            this.grb1.Controls.Add(this.picb);
            this.grb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.grb1.Location = new System.Drawing.Point(238, 41);
            this.grb1.Name = "grb1";
            this.grb1.Size = new System.Drawing.Size(557, 226);
            this.grb1.TabIndex = 2;
            this.grb1.TabStop = false;
            this.grb1.Text = "Thông tin sinh viên";
            // 
            // cmkhoa1
            // 
            this.cmkhoa1.FormattingEnabled = true;
            this.cmkhoa1.Items.AddRange(new object[] {
            "K10",
            "K11",
            "K12",
            "K13",
            "K14"});
            this.cmkhoa1.Location = new System.Drawing.Point(411, 36);
            this.cmkhoa1.Name = "cmkhoa1";
            this.cmkhoa1.Size = new System.Drawing.Size(124, 24);
            this.cmkhoa1.TabIndex = 55;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label20.Location = new System.Drawing.Point(357, 41);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 13);
            this.label20.TabIndex = 54;
            this.label20.Text = "Khóa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.Location = new System.Drawing.Point(143, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Giới tính";
            // 
            // radnu1
            // 
            this.radnu1.AutoSize = true;
            this.radnu1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radnu1.Location = new System.Drawing.Point(269, 133);
            this.radnu1.Name = "radnu1";
            this.radnu1.Size = new System.Drawing.Size(39, 17);
            this.radnu1.TabIndex = 19;
            this.radnu1.Text = "Nữ";
            this.radnu1.UseVisualStyleBackColor = true;
            // 
            // radnam1
            // 
            this.radnam1.AutoSize = true;
            this.radnam1.Checked = true;
            this.radnam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radnam1.Location = new System.Drawing.Point(216, 133);
            this.radnam1.Name = "radnam1";
            this.radnam1.Size = new System.Drawing.Size(47, 17);
            this.radnam1.TabIndex = 18;
            this.radnam1.TabStop = true;
            this.radnam1.Text = "Nam";
            this.radnam1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label4.Location = new System.Drawing.Point(357, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Điểm TB";
            // 
            // txtdiemtb1
            // 
            this.txtdiemtb1.Location = new System.Drawing.Point(411, 70);
            this.txtdiemtb1.Name = "txtdiemtb1";
            this.txtdiemtb1.Size = new System.Drawing.Size(124, 23);
            this.txtdiemtb1.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.Location = new System.Drawing.Point(143, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Lớp";
            // 
            // comblop1
            // 
            this.comblop1.Location = new System.Drawing.Point(216, 97);
            this.comblop1.Name = "comblop1";
            this.comblop1.Size = new System.Drawing.Size(124, 23);
            this.comblop1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(143, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Họ tên";
            // 
            // txthoten1
            // 
            this.txthoten1.Location = new System.Drawing.Point(216, 65);
            this.txthoten1.Name = "txthoten1";
            this.txthoten1.Size = new System.Drawing.Size(124, 23);
            this.txthoten1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label1.Location = new System.Drawing.Point(143, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Mã sinh viên";
            // 
            // txtma1
            // 
            this.txtma1.Location = new System.Drawing.Point(216, 36);
            this.txtma1.Name = "txtma1";
            this.txtma1.Size = new System.Drawing.Size(124, 23);
            this.txtma1.TabIndex = 10;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::QuanLySinhVien_WF.Properties.Resources.info_icon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.button3.Location = new System.Drawing.Point(517, 183);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(34, 37);
            this.button3.TabIndex = 9;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // picb
            // 
            this.picb.BackColor = System.Drawing.Color.Gainsboro;
            this.picb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picb.Location = new System.Drawing.Point(24, 36);
            this.picb.Name = "picb";
            this.picb.Size = new System.Drawing.Size(104, 118);
            this.picb.TabIndex = 6;
            this.picb.TabStop = false;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(572, 8);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(124, 20);
            this.txtSearch.TabIndex = 18;
            // 
            // dgvLop
            // 
            this.dgvLop.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvLop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLop.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dgvLop.Location = new System.Drawing.Point(6, 77);
            this.dgvLop.Name = "dgvLop";
            this.dgvLop.Size = new System.Drawing.Size(209, 184);
            this.dgvLop.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Lớp";
            this.Column1.Name = "Column1";
            this.Column1.Width = 66;
            // 
            // Column2
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Column2.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column2.HeaderText = "Số lượng";
            this.Column2.Name = "Column2";
            // 
            // dgvDssv
            // 
            this.dgvDssv.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvDssv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDssv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3,
            this.Column4,
            this.Column14,
            this.Column5,
            this.Column9,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column10,
            this.Column13,
            this.Column12,
            this.Column11});
            this.dgvDssv.Location = new System.Drawing.Point(7, 273);
            this.dgvDssv.Name = "dgvDssv";
            this.dgvDssv.Size = new System.Drawing.Size(787, 159);
            this.dgvDssv.TabIndex = 0;
            this.dgvDssv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDssv_CellContentClick);
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "MaSV";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Column3.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column3.HeaderText = "Mã sinh viên";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "HoTen";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.Column4.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column4.HeaderText = "Họ tên";
            this.Column4.Name = "Column4";
            this.Column4.Width = 200;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "Khoa";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Column14.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column14.HeaderText = "Khóa";
            this.Column14.Name = "Column14";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Lop";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Column5.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column5.HeaderText = "Lớp";
            this.Column5.Name = "Column5";
            this.Column5.Width = 80;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "GioiTinh";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Column9.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column9.HeaderText = "Giới tính";
            this.Column9.Name = "Column9";
            this.Column9.Width = 50;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "NgaySinh";
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Column6.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column6.HeaderText = "Ngày sinh";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "Email";
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Column7.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column7.HeaderText = "Email";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "DiaChi";
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Column8.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column8.HeaderText = "Địa chỉ";
            this.Column8.Name = "Column8";
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "SoDT";
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Column10.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column10.HeaderText = "Số điện thoại";
            this.Column10.Name = "Column10";
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "DiemTB";
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Column13.DefaultCellStyle = dataGridViewCellStyle11;
            this.Column13.HeaderText = "Điếm TB";
            this.Column13.Name = "Column13";
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "ThanhTich";
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Column12.DefaultCellStyle = dataGridViewCellStyle12;
            this.Column12.HeaderText = "Thành tích";
            this.Column12.Name = "Column12";
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "GhiChu";
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Column11.DefaultCellStyle = dataGridViewCellStyle13;
            this.Column11.HeaderText = "Ghi chú";
            this.Column11.Name = "Column11";
            // 
            // tbp3
            // 
            this.tbp3.Location = new System.Drawing.Point(4, 22);
            this.tbp3.Name = "tbp3";
            this.tbp3.Size = new System.Drawing.Size(800, 472);
            this.tbp3.TabIndex = 2;
            this.tbp3.Text = "Thống kê";
            this.tbp3.UseVisualStyleBackColor = true;
            // 
            // tbp4
            // 
            this.tbp4.Location = new System.Drawing.Point(4, 22);
            this.tbp4.Name = "tbp4";
            this.tbp4.Size = new System.Drawing.Size(800, 472);
            this.tbp4.TabIndex = 3;
            this.tbp4.Text = "Quản lý";
            this.tbp4.UseVisualStyleBackColor = true;
            // 
            // opnfd
            // 
            this.opnfd.FileName = "openFileDialog1";
            this.opnfd.FileOk += new System.ComponentModel.CancelEventHandler(this.opnfd_FileOk);
            // 
            // TimerNext
            // 
            this.TimerNext.Tick += new System.EventHandler(this.TimerNext_Tick);
            // 
            // TimerPre
            // 
            this.TimerPre.Tick += new System.EventHandler(this.TimerPre_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 506);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Chương Trình Quản Lý Sinh Viên";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tbp2.ResumeLayout(false);
            this.tbp2.PerformLayout();
            this.grb2.ResumeLayout(false);
            this.grb2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb2)).EndInit();
            this.grb1.ResumeLayout(false);
            this.grb1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDssv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tbp1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbp3;
        private System.Windows.Forms.TabPage tbp4;
        private System.Windows.Forms.TabPage tbp2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbKhoa;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox grb1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radnu1;
        private System.Windows.Forms.RadioButton radnam1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdiemtb1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox comblop1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txthoten1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtma1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox picb;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvLop;
        private System.Windows.Forms.DataGridView dgvDssv;
        private System.Windows.Forms.OpenFileDialog opnfd;
        private System.Windows.Forms.GroupBox grb2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtghichu2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtdiachi2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtmail2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radnu;
        private System.Windows.Forms.RadioButton radnam;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txthoten2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtma2;
        private System.Windows.Forms.PictureBox picb2;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThemMoi;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtthanhtich;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtdiemtb2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtsdt2;
        private System.Windows.Forms.Timer TimerNext;
        private System.Windows.Forms.Timer TimerPre;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btnXoaAnh;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.ComboBox combLop2;
        private System.Windows.Forms.ComboBox cmbKhoasv;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmkhoa1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker datpDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
    }
}

